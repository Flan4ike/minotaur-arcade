param(
    [string]$GamePath = 'D:\SteamLibrary\steamapps\common\Stardew Valley'
)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$project = Join-Path $PSScriptRoot 'MinotaurArcade\MinotaurArcade.csproj'
$targetDir = Join-Path $GamePath 'Mods\MinotaurArcade'
$sourceDir = Join-Path $PSScriptRoot 'MinotaurArcade\bin\Release\net6.0'

Write-Host '=== MINOTAUR ARCADE: BUILD & INSTALL ==='
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    Write-Host 'ERROR: .NET SDK not installed. Runtime alone is not enough.' -ForegroundColor Red
    Write-Host 'Install .NET SDK with .NET 6 targeting support:'
    Write-Host 'https://dotnet.microsoft.com/download/dotnet/6.0'
    Write-Host 'Restart PowerShell after installation, then run this script again.'
    exit 2
}
$sdkList = @(dotnet --list-sdks)
if ($LASTEXITCODE -ne 0 -or $sdkList.Count -eq 0) {
    Write-Host 'ERROR: dotnet found but no SDKs installed.' -ForegroundColor Red
    exit 3
}
if (-not (Test-Path (Join-Path $GamePath 'Stardew Valley.dll'))) {
    Write-Host "ERROR: Stardew Valley not found at: $GamePath" -ForegroundColor Red
    Write-Host 'Example: .\Build_And_Install.ps1 -GamePath "D:\SteamLibrary\steamapps\common\Stardew Valley"'
    exit 4
}
Write-Host 'Building .NET 6 mod project...'
& dotnet build $project --configuration Release "-p:GamePath=$GamePath" -v minimal
if ($LASTEXITCODE -ne 0) {
    Write-Host 'ERROR: Build failed; read the error messages above.' -ForegroundColor Red
    exit $LASTEXITCODE
}
$dllPath = Join-Path $sourceDir 'MinotaurArcade.dll'
if (-not (Test-Path $dllPath)) { throw "DLL not found: $dllPath" }
New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $targetDir 'assets') -Force | Out-Null
Copy-Item $dllPath $targetDir -Force
Copy-Item (Join-Path $PSScriptRoot 'MinotaurArcade\manifest.json') $targetDir -Force
Copy-Item (Join-Path $PSScriptRoot 'MinotaurArcade\assets\*.png') (Join-Path $targetDir 'assets') -Force
Write-Host "Installed successfully to: $targetDir" -ForegroundColor Green
Write-Host 'In the SMAPI console, use arcade_give while a save is loaded.'
