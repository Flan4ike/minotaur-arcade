using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewModdingAPI;
using StardewModdingAPI.Events;
using StardewModdingAPI.Utilities;
using StardewValley;
using StardewValley.GameData.BigCraftables;

namespace MinotaurArcade;

public sealed class ModEntry : Mod
{
    public const string ClassicId = "Flan.MinotaurArcade_Classic";
    public const string SurvivalId = "Flan.MinotaurArcade_Survival";
    internal readonly Dictionary<string, LobbyData> Lobbies = new();
    internal LobbyData? CurrentLobby;
    private int heartbeat;
    internal Texture2D? MinotaurTexture;

    public override void Entry(IModHelper helper)
    {
        helper.Events.Content.AssetRequested += OnAssetRequested;
        helper.Events.Input.ButtonPressed += OnButtonPressed;
        helper.Events.GameLoop.UpdateTicked += OnUpdate;
        helper.Events.GameLoop.SaveLoaded += (_, _) => Reset();
        helper.Events.GameLoop.ReturnedToTitle += (_, _) => Reset();
        helper.Events.Multiplayer.ModMessageReceived += OnMessage;
        helper.Events.Multiplayer.PeerDisconnected += OnDisconnect;
        helper.ConsoleCommands.Add("arcade_give", "Give both Minotaur Arcade cabinets: arcade_give", (_, _) => GiveCabinets());
        helper.ConsoleCommands.Add("arcade_menu", "Open Minotaur Arcade menu: arcade_menu", (_, _) =>
        {
            if (Context.IsWorldReady) OpenCabinet(0);
        });
    }

    private void Reset()
    {
        Lobbies.Clear();
        CurrentLobby = null;
        heartbeat = 0;
    }

    private void OnAssetRequested(object? sender, AssetRequestedEventArgs e)
    {
        if (e.NameWithoutLocale.IsEquivalentTo("Mods/Flan.MinotaurArcade/Cabinets"))
        {
            e.LoadFromModFile<Texture2D>("assets/cabinets.png", AssetLoadPriority.Medium);
        }
        else if (e.NameWithoutLocale.IsEquivalentTo("Data/BigCraftables"))
        {
            e.Edit(asset =>
            {
                var data = asset.AsDictionary<string, BigCraftableData>().Data;
                data[ClassicId] = new BigCraftableData
                {
                    Name = "Minotaur Maze Arcade",
                    DisplayName = "Автомат: Лабиринт",
                    Description = "Найди выход раньше, чем тебя настигнет минотавр.",
                    Texture = "Mods/Flan.MinotaurArcade/Cabinets",
                    SpriteIndex = 0,
                    CanBePlacedIndoors = true,
                    CanBePlacedOutdoors = true
                };
                data[SurvivalId] = new BigCraftableData
                {
                    Name = "Minotaur Survival Arcade",
                    DisplayName = "Автомат: Выживание",
                    Description = "Продержись в лабиринте 90 секунд.",
                    Texture = "Mods/Flan.MinotaurArcade/Cabinets",
                    SpriteIndex = 1,
                    CanBePlacedIndoors = true,
                    CanBePlacedOutdoors = true
                };
            }, AssetEditPriority.Default);
        }
    }

    private void GiveCabinets()
    {
        if (!Context.IsWorldReady) { Monitor.Log("Load a save first.", LogLevel.Warn); return; }
        foreach (string id in new[] { ClassicId, SurvivalId })
        {
            var item = ItemRegistry.Create("(BC)" + id);
            if (!Game1.player.addItemToInventoryBool(item))
                Monitor.Log("Inventory is full; free a slot and run arcade_give again.", LogLevel.Warn);
        }
    }

    private void OnButtonPressed(object? sender, ButtonPressedEventArgs e)
    {
        if (!Context.IsWorldReady || Game1.activeClickableMenu != null)
            return;
        if (e.Button != SButton.MouseRight && e.Button != SButton.ControllerA)
            return;
        Vector2 tile = e.Cursor.GrabTile;
        // The grab tile works with both mouse interaction and controllers.
        if (!Game1.currentLocation.objects.TryGetValue(tile, out StardewValley.Object? item) || item == null)
            return;
        int mode = item.ItemId == ClassicId ? 0 : item.ItemId == SurvivalId ? 1 : -1;
        if (mode < 0) return;
        if (Vector2.Distance(Game1.player.Tile, tile) > 2.5f) return;
        Helper.Input.Suppress(e.Button);
        OpenCabinet(mode);
    }

    internal void OpenCabinet(int mode)
    {
        Game1.activeClickableMenu = new ArcadeMenu(this, mode, ArcadeMenu.Page.Home);
    }

    private void OnUpdate(object? sender, UpdateTickedEventArgs e)
    {
        if (!Context.IsWorldReady) return;
        if (Game1.activeClickableMenu is MazeMenu maze)
            maze.Tick(e.IsMultipleOf(6));
        if (++heartbeat >= 180)
        {
            heartbeat = 0;
            if (CurrentLobby != null && CurrentLobby.OwnerId == Game1.player.UniqueMultiplayerID && !CurrentLobby.Started)
                Broadcast("LobbyAdvert", CurrentLobby);
        }
    }

    internal void Broadcast<T>(string kind, T data) where T : class =>
        Helper.Multiplayer.SendMessage(data, kind, modIDs: new[] { ModManifest.UniqueID });

    internal void QueryLobbies()
    {
        Lobbies.Clear();
        if (CurrentLobby is { Started: false }) Lobbies[CurrentLobby.Id] = CurrentLobby;
        Broadcast("LobbyQuery", new LobbyControl());
    }

    internal void CreateLobby(int mode)
    {
        LeaveLobby();
        CurrentLobby = new LobbyData
        {
            Id = Guid.NewGuid().ToString("N"), Mode = mode,
            OwnerId = Game1.player.UniqueMultiplayerID,
            OwnerName = Game1.player.Name,
            Players = new List<long> { Game1.player.UniqueMultiplayerID },
            PlayerNames = new List<string> { Game1.player.Name },
            Seed = Random.Shared.Next(1, int.MaxValue)
        };
        Lobbies[CurrentLobby.Id] = CurrentLobby;
        Broadcast("LobbyAdvert", CurrentLobby);
        Game1.activeClickableMenu = new ArcadeMenu(this, mode, ArcadeMenu.Page.Waiting);
    }

    internal void JoinLobby(string id)
    {
        if (!Lobbies.TryGetValue(id, out var lobby) || lobby.Started) return;
        if (CurrentLobby != null) LeaveLobby();
        CurrentLobby = lobby;
        Broadcast("LobbyJoin", new LobbyRequest { LobbyId = id, PlayerName = Game1.player.Name });
        Game1.activeClickableMenu = new ArcadeMenu(this, lobby.Mode, ArcadeMenu.Page.Waiting);
    }

    internal void LeaveLobby()
    {
        if (CurrentLobby is null) return;
        var lobby = CurrentLobby;
        Broadcast("LobbyLeave", new LobbyControl { LobbyId = lobby.Id, PlayerId = Game1.player.UniqueMultiplayerID });
        if (lobby.OwnerId == Game1.player.UniqueMultiplayerID)
        {
            Broadcast("LobbyClosed", new LobbyControl { LobbyId = lobby.Id });
            Lobbies.Remove(lobby.Id);
        }
        CurrentLobby = null;
    }

    internal void StartLobby()
    {
        if (CurrentLobby is not { Started: false } lobby || lobby.OwnerId != Game1.player.UniqueMultiplayerID)
            return;
        lobby.Started = true;
        Broadcast("LobbyStarted", lobby);
        Launch(lobby);
    }

    internal void LaunchSolo(int mode)
    {
        LeaveLobby();
        var solo = new LobbyData
        {
            Id = "solo-" + Guid.NewGuid().ToString("N"), Mode = mode,
            Seed = Random.Shared.Next(1, int.MaxValue),
            OwnerId = Game1.player.UniqueMultiplayerID,
            Players = new List<long> { Game1.player.UniqueMultiplayerID },
            PlayerNames = new List<string> { Game1.player.Name },
            Started = true
        };
        Launch(solo, true);
    }

    private void Launch(LobbyData lobby, bool solo = false)
    {
        try
        {
            MinotaurTexture ??= Helper.ModContent.Load<Texture2D>("assets/minotaur.png");
            Game1.activeClickableMenu = new MazeMenu(this, lobby, solo);
        }
        catch (Exception ex)
        {
            Monitor.Log($"Could not start arcade: {ex}", LogLevel.Error);
            Game1.addHUDMessage(new HUDMessage("Arcade start failed; see SMAPI log."));
            OpenCabinet(lobby.Mode);
        }
    }

    private void OnDisconnect(object? sender, PeerDisconnectedEventArgs e)
    {
        foreach (var lobby in Lobbies.Values.ToList())
        {
            if (lobby.OwnerId == e.Peer.PlayerID)
            {
                Lobbies.Remove(lobby.Id);
                if (CurrentLobby?.Id == lobby.Id)
                {
                    CurrentLobby = null;
                    if (Game1.activeClickableMenu is ArcadeMenu) OpenCabinet(lobby.Mode);
                    if (Game1.activeClickableMenu is MazeMenu running) running.CancelFromHost();
                }
            }
            else
            {
                int index = lobby.Players.IndexOf(e.Peer.PlayerID);
                if (index >= 0) { lobby.Players.RemoveAt(index); lobby.PlayerNames.RemoveAt(index); }
            }
        }
    }

    private void OnMessage(object? sender, ModMessageReceivedEventArgs e)
    {
        if (!Context.IsWorldReady || e.FromModID != ModManifest.UniqueID) return;
        try
        {
            switch (e.Type)
            {
                case "LobbyQuery":
                    if (CurrentLobby is { Started: false } owned && owned.OwnerId == Game1.player.UniqueMultiplayerID)
                        Broadcast("LobbyAdvert", owned);
                    break;
                case "LobbyAdvert":
                {
                    var lobby = e.ReadAs<LobbyData>();
                    if (!lobby.Started)
                    {
                        Lobbies[lobby.Id] = lobby;
                        if (CurrentLobby?.Id == lobby.Id) CurrentLobby = lobby;
                    }
                    break;
                }
                case "LobbyJoin":
                {
                    var req = e.ReadAs<LobbyRequest>();
                    if (CurrentLobby is { Started: false } owner && owner.OwnerId == Game1.player.UniqueMultiplayerID
                        && owner.Id == req.LobbyId && !owner.Players.Contains(e.FromPlayerID))
                    {
                        if (owner.Players.Count >= 4)
                            Broadcast("LobbyRejected", new LobbyControl { LobbyId = owner.Id, PlayerId = e.FromPlayerID });
                        else
                        {
                            owner.Players.Add(e.FromPlayerID);
                            owner.PlayerNames.Add(req.PlayerName);
                            Broadcast("LobbyAdvert", owner);
                        }
                    }
                    break;
                }
                case "LobbyLeave":
                {
                    var req = e.ReadAs<LobbyControl>();
                    if (CurrentLobby is { Started: false } owner && owner.OwnerId == Game1.player.UniqueMultiplayerID
                        && owner.Id == req.LobbyId && e.FromPlayerID == req.PlayerId)
                    {
                        int index = owner.Players.IndexOf(req.PlayerId);
                        if (index >= 0) { owner.Players.RemoveAt(index); owner.PlayerNames.RemoveAt(index); }
                        Broadcast("LobbyAdvert", owner);
                    }
                    break;
                }
                case "LobbyRejected":
                {
                    var req = e.ReadAs<LobbyControl>();
                    if (CurrentLobby?.Id == req.LobbyId && req.PlayerId == Game1.player.UniqueMultiplayerID
                        && CurrentLobby.OwnerId == e.FromPlayerID)
                    {
                        int rejectedMode = CurrentLobby.Mode;
                        CurrentLobby = null;
                        OpenCabinet(rejectedMode);
                        Game1.addHUDMessage(new HUDMessage("Arcade lobby is full."));
                    }
                    break;
                }
                case "LobbyClosed":
                {
                    var req = e.ReadAs<LobbyControl>();
                    if (Lobbies.TryGetValue(req.LobbyId, out var closed) && closed.OwnerId == e.FromPlayerID)
                    {
                        Lobbies.Remove(req.LobbyId);
                        if (CurrentLobby?.Id == req.LobbyId)
                        {
                            CurrentLobby = null;
                            if (Game1.activeClickableMenu is ArcadeMenu) OpenCabinet(closed.Mode);
                            if (Game1.activeClickableMenu is MazeMenu running) running.CancelFromHost();
                        }
                    }
                    break;
                }
                case "LobbyStarted":
                {
                    var started = e.ReadAs<LobbyData>();
                    if (CurrentLobby?.Id == started.Id && started.OwnerId == e.FromPlayerID
                        && started.Players.Contains(Game1.player.UniqueMultiplayerID))
                    {
                        CurrentLobby = started;
                        Lobbies[started.Id] = started;
                        Launch(started);
                    }
                    break;
                }
                case "PlayerState":
                    if (Game1.activeClickableMenu is MazeMenu maze) maze.ReceivePlayer(e.FromPlayerID, e.ReadAs<PlayerPacket>());
                    break;
                case "MonsterState":
                    if (Game1.activeClickableMenu is MazeMenu game) game.ReceiveMonster(e.FromPlayerID, e.ReadAs<MonsterPacket>());
                    break;
            }
        }
        catch (Exception ex) { Monitor.Log($"Arcade network error ({e.Type}): {ex}", LogLevel.Error); }
    }
}
