using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using StardewValley;
using StardewValley.Menus;

namespace MinotaurArcade;

// Pseudo-3D voxel dungeon. The tile grid is synchronized by the lobby owner;
// all players move locally while mining, placement, shots and enemy waves are host-authoritative.
internal sealed class BlockGameMenu : IClickableMenu
{
    private readonly ModEntry mod;
    private readonly LobbyData lobby;
    private readonly bool solo;
    private readonly bool host;
    private readonly bool siege;
    private readonly long me;
    private readonly BlockWorld world;
    private readonly Dictionary<long, Avatar> players = new();
    private readonly Avatar local;
    private readonly List<BlockEnemyPacket> enemies = new();
    private readonly Random rand;
    private float clock;
    private float attackCooldown;
    private float enemyThink;
    private bool wasMine, wasPlace, wasShoot;
    private bool finished, won, dismissed;
    private int stone=5, crystals=0, coreHealth=15, wave;
    private string feedback = "";
    private float feedbackTimer;
    private const float Fov = 1.06f;
    private const int TargetCrystals = 14;
    private static readonly Color[] Materials = {new(15,17,21),new(122,119,127),new(176,103,58),new(62,190,229),new(40,41,55),new(157,151,129)};

    internal BlockGameMenu(ModEntry mod, LobbyData lobby, bool solo) : base(0,0,Game1.uiViewport.Width,Game1.uiViewport.Height)
    {
        this.mod=mod;this.lobby=lobby;this.solo=solo;
        host=solo || lobby.OwnerId==Game1.player.UniqueMultiplayerID;
        siege=lobby.Mode==3;me=Game1.player.UniqueMultiplayerID;
        world=new BlockWorld(lobby.Seed);rand=new Random(lobby.Seed^0x58EA7);
        foreach(long id in lobby.Players) players[id]=new Avatar {X=11.5f,Y=11.5f};
        if(!players.ContainsKey(me)) players[me]=new Avatar {X=11.5f,Y=11.5f};
        local=players[me]; local.Angle=0;
        stone=siege?12:5;
        Game1.playSound("doorClose");
    }

    internal void Tick(bool send)
    {
        if(dismissed) return;
        const float dt=1f/60f;
        if(feedbackTimer>0) feedbackTimer-=dt;
        attackCooldown=Math.Max(0,attackCooldown-dt);
        KeyboardState keys=Keyboard.GetState();
        if(!finished)
        {
            Move(keys,dt);
            bool mine=keys.IsKeyDown(Keys.F), place=keys.IsKeyDown(Keys.G), shoot=keys.IsKeyDown(Keys.Space);
            if(mine && !wasMine) Interact("mine");
            if(place && !wasPlace) Interact("place");
            if(shoot && !wasShoot && attackCooldown<=0) {attackCooldown=.4f;Interact("shoot");}
            wasMine=mine;wasPlace=place;wasShoot=shoot;
            if(host)
            {
                clock+=dt;
                if(siege) UpdateSiege(dt);
                if(!siege && crystals>=TargetCrystals) End(true);
            }
        }
        if(!solo && send)
        {
            mod.Broadcast("BlockPlayer",new PlayerPacket {LobbyId=lobby.Id,X=local.X,Y=local.Y,Angle=local.Angle});
            if(host) SendWorld();
        }
    }
    private void Move(KeyboardState keys,float dt)
    {
        float turn=(keys.IsKeyDown(Keys.D)||keys.IsKeyDown(Keys.Right)?1:0)-(keys.IsKeyDown(Keys.A)||keys.IsKeyDown(Keys.Left)?1:0);
        local.Angle+=turn*2.55f*dt;
        float f=(keys.IsKeyDown(Keys.W)||keys.IsKeyDown(Keys.Up)?1:0)-(keys.IsKeyDown(Keys.S)||keys.IsKeyDown(Keys.Down)?1:0);
        float side=(keys.IsKeyDown(Keys.E)?1:0)-(keys.IsKeyDown(Keys.Q)?1:0);
        float sp=(keys.IsKeyDown(Keys.LeftShift)?3.5f:2.5f)*dt;
        float dx=(MathF.Cos(local.Angle)*f-MathF.Sin(local.Angle)*side)*sp;
        float dy=(MathF.Sin(local.Angle)*f+MathF.Cos(local.Angle)*side)*sp;
        if(world.Open(local.X+dx,local.Y)) local.X+=dx;
        if(world.Open(local.X,local.Y+dy)) local.Y+=dy;
    }
    private void Interact(string kind)
    {
        if(host) ApplyAction(me,kind,local.Angle);
        else mod.Broadcast("BlockAction",new BlockActionPacket {LobbyId=lobby.Id,Action=kind,Angle=local.Angle});
    }
    internal void ReceiveAction(long sender,BlockActionPacket request)
    {
        if(host && !finished && request.LobbyId==lobby.Id && players.ContainsKey(sender) &&
            (request.Action=="mine" || request.Action=="place" || request.Action=="shoot"))
        { ApplyAction(sender,request.Action,request.Angle);SendWorld(); }
    }
    internal void ReceivePlayer(long sender,PlayerPacket packet)
    {
        if(packet.LobbyId!=lobby.Id || !players.TryGetValue(sender,out Avatar? avatar) || sender==me) return;
        if(packet.X>=1 && packet.Y>=1 && packet.X<BlockWorld.Size-1 && packet.Y<BlockWorld.Size-1 &&
           world.Open(packet.X,packet.Y))
        {avatar.X=packet.X;avatar.Y=packet.Y;avatar.Angle=packet.Angle;}
    }
    internal void ReceiveWorld(long sender,BlockWorldPacket packet)
    {
        if(host || sender!=lobby.OwnerId || packet.LobbyId!=lobby.Id || packet.Cells.Length!=BlockWorld.Size*BlockWorld.Size) return;
        world.Apply(packet.Cells);stone=packet.Stone;crystals=packet.Crystals;coreHealth=packet.CoreHealth;
        wave=packet.Wave;clock=packet.Seconds;enemies.Clear();enemies.AddRange(packet.Enemies);
        if(packet.Finished && !finished) Game1.playSound(packet.Won?"reward":"thunder");
        finished=packet.Finished;won=packet.Won;
    }
    private void SendWorld()
    {
        mod.Broadcast("BlockWorld",new BlockWorldPacket {LobbyId=lobby.Id,Cells=(int[])world.Tiles.Clone(),
            Enemies=enemies.Select(e=>new BlockEnemyPacket {X=e.X,Y=e.Y,Health=e.Health}).ToList(),
            Stone=stone,Crystals=crystals,CoreHealth=coreHealth,Wave=wave,Seconds=clock,Finished=finished,Won=won});
    }
    private void ApplyAction(long sender,string kind,float aim)
    {
        if(!players.TryGetValue(sender,out Avatar? a) || finished) return;
        // Use the known player position, never arbitrary coordinates supplied by the client.
        float angle=Math.Clamp(aim,-50000f,50000f);
        if(float.IsNaN(angle) || float.IsInfinity(angle)) return;
        float dirX=MathF.Cos(angle),dirY=MathF.Sin(angle);
        if(kind=="shoot")
        {
            if(!siege) return;
            BlockEnemyPacket? hit=null;float distance=6.5f;
            foreach(var enemy in enemies)
            {
                float dx=enemy.X-a.X,dy=enemy.Y-a.Y,d=dx*dirX+dy*dirY;
                if(d<.2f||d>distance) continue;
                float lateral=MathF.Abs(dx*dirY-dy*dirX);
                if(lateral>.32f) continue;
                bool blocked=false;
                for(float t=.2f;t<d;t+=.13f)
                    if(world.Get((int)(a.X+dirX*t),(int)(a.Y+dirY*t))!=0) {blocked=true;break;}
                if(!blocked) {hit=enemy;distance=d;}
            }
            if(hit!=null)
            {
                hit.Health--;
                if(hit.Health<=0) {enemies.Remove(hit);if(sender==me) Game1.playSound("coin");}
            }
            else if(sender==me) Inform("ЦЕЛЬ НЕ НАЙДЕНА");
            return;
        }
        for(float distance=.25f;distance<=2.9f;distance+=.10f)
        {
            int x=(int)(a.X+dirX*distance),y=(int)(a.Y+dirY*distance);
            int type=world.Get(x,y);
            if(kind=="mine" && type>0)
            {
                if(type==4) {if(sender==me) Inform("КОРЕННАЯ ПОРОДА НЕ ЛОМАЕТСЯ");return;}
                world.Set(x,y,0);
                stone++;
                if(type==3) crystals++;
                if(sender==me){Game1.playSound("hammer");Inform(type==3?"+1 КРИСТАЛЛ!":"+1 БЛОК");}
                return;
            }
            if(kind=="place" && type>0) return;
            if(kind=="place" && distance>=1.25f && type==0)
            {
                if(stone<=0 || (Math.Abs(x-11)<=1 && Math.Abs(y-11)<=1)) return;
                foreach(var p in players.Values) if((p.X-x-.5f)*(p.X-x-.5f)+(p.Y-y-.5f)*(p.Y-y-.5f)<1.0f) return;
                foreach(var e in enemies) if((e.X-x-.5f)*(e.X-x-.5f)+(e.Y-y-.5f)*(e.Y-y-.5f)<.7f) return;
                if(world.Set(x,y,5)) {stone--;if(sender==me)Game1.playSound("stoneStep");}
                return;
            }
        }
    }
    private void Inform(string msg){feedback=msg;feedbackTimer=2.0f;}
    private void SpawnWave(int count)
    {
        for(int i=0;i<count;i++)
        {
            for(int retry=0;retry<100;retry++)
            {
                int x=rand.Next(2,BlockWorld.Size-2),y=rand.Next(2,BlockWorld.Size-2);
                if(Math.Abs(x-11)+Math.Abs(y-11)<10 || world.Get(x,y)!=0) continue;
                enemies.Add(new BlockEnemyPacket {X=x+.5f,Y=y+.5f,Health=2+wave});break;
            }
        }
    }
    private void UpdateSiege(float dt)
    {
        int shouldWave=clock>=64?3:clock>=36?2:clock>=5?1:0;
        if(shouldWave>wave){wave=shouldWave;SpawnWave(3+wave*2);Game1.playSound("thunder");}
        enemyThink-=dt;
        if(enemyThink<=0)
        {
            enemyThink=.24f;
            foreach(var e in enemies.ToArray())
            {
                float dx=11.5f-e.X,dy=11.5f-e.Y;
                if(dx*dx+dy*dy<1.2f)
                {
                    coreHealth--;enemies.Remove(e);continue;
                }
                (int nx,int ny)=StepToward((int)e.X,(int)e.Y,11,11);
                float tx=nx+.5f,ty=ny+.5f;
                float mx=tx-e.X,my=ty-e.Y,length=MathF.Sqrt(mx*mx+my*my);
                if(length>.05f)
                {
                    float move=Math.Min(.40f,length);
                    float nextX=e.X+mx/length*move,nextY=e.Y+my/length*move;
                    if(world.Open(nextX,nextY)){e.X=nextX;e.Y=nextY;}
                }
            }
            if(coreHealth<=0) End(false);
        }
        if(clock>=100) End(coreHealth>0);
    }
    private (int x,int y) StepToward(int sx,int sy,int tx,int ty)
    {
        int n=BlockWorld.Size;int[] d=new int[n*n];Array.Fill(d,-1);
        var q=new Queue<(int x,int y)>();d[tx+ty*n]=0;q.Enqueue((tx,ty));
        var dirs=new (int x,int y)[]{(1,0),(-1,0),(0,1),(0,-1)};
        while(q.Count>0)
        {
            var (x,y)=q.Dequeue();
            foreach(var (ox,oy) in dirs)
            {
                int nx=x+ox,ny=y+oy;if(world.Get(nx,ny)!=0||d[nx+ny*n]>=0)continue;
                d[nx+ny*n]=d[x+y*n]+1;q.Enqueue((nx,ny));
            }
        }
        int bx=sx,by=sy,best=d[sx+sy*n];
        foreach(var (ox,oy) in dirs)
        {
            int nx=sx+ox,ny=sy+oy;
            if(world.Get(nx,ny)!=0)continue;
            int val=d[nx+ny*n];if(val>=0 && (best<0 || val<best)){best=val;bx=nx;by=ny;}
        }
        return (bx,by);
    }
    private void End(bool success)
    {
        if(finished)return;
        finished=true;won=success;Game1.playSound(success?"reward":"thunder");
        if(!solo)SendWorld();
    }
    internal void CancelFromHost(){finished=true;won=false;}
    public override void receiveKeyPress(Keys key)
    {
        if(key==Keys.Escape){Exit();return;}
        if(key==Keys.R && finished && solo)mod.LaunchSolo(lobby.Mode);
    }
    private void Exit()
    {
        dismissed=true;
        if(!solo)mod.LeaveLobby();
        mod.OpenCabinet(lobby.Mode);
    }
    public override void draw(SpriteBatch b)
    {
        int w=Game1.uiViewport.Width,h=Game1.uiViewport.Height,pad=Math.Min(34,w/22);
        ArcadeMenu.Fill(b,new Rectangle(0,0,w,h),new Color(13,14,23));
        Rectangle screen=new(pad,65,Math.Max(120,w-2*pad),Math.Max(120,h-173));
        ArcadeMenu.Box(b,new Rectangle(screen.X-3,screen.Y-3,screen.Width+6,screen.Height+6),Palette.Gold,Palette.Dark);
        DrawView(b,screen);DrawMap(b,screen);
        string title=siege?"CRYSTAL SIEGE / ЗАЩИТИ КРИСТАЛЛ":"BLOCK CAVERNS / ДОБУДЬ КРИСТАЛЛЫ";
        ArcadeMenu.Text(b,title,pad,18,Palette.Gold,.94f);
        ArcadeMenu.Text(b,siege?$"ВОЛНА {wave}/3   КРИСТАЛЛ HP: {coreHealth}/15   БЛОКИ: {stone}   ВРЕМЯ: {Math.Max(0,100-clock):0}"
            :$"КРИСТАЛЛЫ: {crystals}/{TargetCrystals}   БЛОКИ: {stone}   ИГРОКИ: {players.Count}",pad,screen.Bottom+10,Palette.Cream,.84f);
        ArcadeMenu.Text(b,siege?"WASD — движение   Q/E — вбок   F — добыть   G — поставить   SPACE — стрелять   ESC — выход"
            :"WASD — движение   Q/E — вбок   F — добыть   G — поставить   ESC — выход",pad,h-42,Palette.Gold,.71f);
        if(feedbackTimer>0)ArcadeMenu.Text(b,feedback,pad+10,screen.Y+16,Palette.Cream,.9f);
        if(finished)
        {
            int bw=Math.Min(screen.Width-30,650),bx=screen.Center.X-bw/2,by=screen.Center.Y-86;
            ArcadeMenu.Box(b,new Rectangle(bx,by,bw,173),Palette.Gold,new Color(31,24,46));
            ArcadeMenu.Text(b,won?"ПОБЕДА!":"ИСПЫТАНИЕ ПРОВАЛЕНО",bx+22,by+25,won?Palette.Gold:new Color(247,110,100),1.25f);
            ArcadeMenu.Text(b,solo?"R — снова   ESC — к автомату":"ESC — к автомату",bx+24,by+107,Palette.Cream,.83f);
        }
        drawMouse(b);
    }
    private void DrawView(SpriteBatch b,Rectangle area)
    {
        int horizon=area.Center.Y;
        ArcadeMenu.Fill(b,new Rectangle(area.X,area.Y,area.Width,area.Height/2),siege?new Color(30,17,41):new Color(24,41,51));
        ArcadeMenu.Fill(b,new Rectangle(area.X,horizon,area.Width,area.Bottom-horizon),new Color(53,50,43));
        for(int i=1;i<=12;i++)
        {int y=horizon+i*i*area.Height/300;if(y<area.Bottom)ArcadeMenu.Fill(b,new Rectangle(area.X,y,area.Width,1),new Color(96,87,80)*.28f);}
        const int cw=4;int cols=(area.Width+cw-1)/cw;float[] depths=new float[cols];
        for(int i=0;i<cols;i++)
        {
            float ray=local.Angle-Fov/2+(i+.5f)*Fov/cols;
            float rx=MathF.Cos(ray),ry=MathF.Sin(ray);
            int gx=(int)local.X,gy=(int)local.Y;
            float ddx=MathF.Abs(rx)<.00001f?1e6f:MathF.Abs(1f/rx),ddy=MathF.Abs(ry)<.00001f?1e6f:MathF.Abs(1f/ry);
            int stepx=rx<0?-1:1,stepy=ry<0?-1:1;
            float sx=(rx<0?local.X-gx:gx+1-local.X)*ddx,sy=(ry<0?local.Y-gy:gy+1-local.Y)*ddy;
            bool side=false;
            int type=4;
            for(int t=0;t<55;t++)
            {
                if(sx<sy){sx+=ddx;gx+=stepx;side=false;}
                else{sy+=ddy;gy+=stepy;side=true;}
                type=world.Get(gx,gy);if(type!=0)break;
            }
            float dist=Math.Max(.08f,(side?sy-ddy:sx-ddx)*MathF.Cos(ray-local.Angle));depths[i]=dist;
            int wallHeight=Math.Min(area.Height*4,(int)(area.Height*.9f/dist));
            int top=horizon-wallHeight/2,visibleTop=Math.Max(top,area.Y),visibleBottom=Math.Min(top+wallHeight,area.Bottom);
            if(visibleBottom<=visibleTop)continue;
            float light=Math.Clamp(1.13f/(1+dist*.12f),.22f,1f)*(side?.76f:1f);
            Color tint=Materials[Math.Clamp(type,0,Materials.Length-1)]*light;
            int left=area.X+i*cw,width=Math.Min(cw,area.Right-left);
            ArcadeMenu.Fill(b,new Rectangle(left,visibleTop,width,visibleBottom-visibleTop),tint);
            int blockStripe=Math.Max(10,wallHeight/6);
            for(int yy=top+blockStripe;yy<visibleBottom;yy+=blockStripe)
                if(yy>=visibleTop)ArcadeMenu.Fill(b,new Rectangle(left,yy,width,Math.Max(1,wallHeight/210)),new Color(20,24,27)*light);
            if(i%8==0)ArcadeMenu.Fill(b,new Rectangle(left,visibleTop,1,visibleBottom-visibleTop),new Color(13,18,22)*light);
            if(type==3 && i%3==0)ArcadeMenu.Fill(b,new Rectangle(left,visibleTop+Math.Min(8,(visibleBottom-visibleTop)/3),width,Math.Max(1,(visibleBottom-visibleTop)/14)),new Color(182,248,254)*light*.6f);
        }
        var sprites=new List<(float x,float y,Color color,float size)>();
        if(siege)
        {
            sprites.Add((11.5f,11.5f,new Color(120,252,245),.55f));
            foreach(var enemy in enemies)sprites.Add((enemy.X,enemy.Y,new Color(245,98,145),.75f));
        }
        foreach(var kv in players)if(kv.Key!=me)sprites.Add((kv.Value.X,kv.Value.Y,new Color(77,210,255),.75f));
        foreach(var obj in sprites.OrderByDescending(s=>(s.x-local.X)*(s.x-local.X)+(s.y-local.Y)*(s.y-local.Y)))
            DrawSprite(b,area,depths,obj.x,obj.y,obj.color,obj.size);
        ArcadeMenu.Fill(b,new Rectangle(area.Center.X-9,area.Center.Y,18,2),Palette.Cream*.7f);
        ArcadeMenu.Fill(b,new Rectangle(area.Center.X,area.Center.Y-9,2,18),Palette.Cream*.7f);
    }
    private void DrawSprite(SpriteBatch b,Rectangle area,float[] depths,float x,float y,Color tint,float size)
    {
        float dx=x-local.X,dy=y-local.Y,dist=MathF.Sqrt(dx*dx+dy*dy);
        if(dist<.2f)return;
        float angle=MathF.Atan2(dy,dx)-local.Angle;
        while(angle>MathF.PI)angle-=MathF.Tau;while(angle<-MathF.PI)angle+=MathF.Tau;
        if(MathF.Abs(angle)>Fov*.67f)return;
        float adjusted=dist*MathF.Cos(angle),cx=area.Center.X+angle/Fov*area.Width;
        int idx=Math.Clamp((int)((cx-area.X)/4),0,depths.Length-1);
        if(adjusted>depths[idx]+.08f)return;
        int hh=Math.Min(area.Height*2,(int)(area.Height*size/Math.Max(.2f,adjusted)));
        int ww=Math.Max(3,hh/2);Rectangle rect=new((int)cx-ww/2,area.Center.Y-hh/2,ww,hh);
        ArcadeMenu.Fill(b,rect,tint);
        ArcadeMenu.Fill(b,new Rectangle(rect.X+ww/4,rect.Y+hh/5,Math.Max(1,ww/2),Math.Max(1,hh/6)),Color.White*.75f);
    }
    private void DrawMap(SpriteBatch b,Rectangle area)
    {
        int cell=Math.Clamp(Math.Min(area.Width/38,area.Height/29),4,9),size=BlockWorld.Size*cell;
        int x=area.Right-size-14,y=area.Y+14;
        ArcadeMenu.Fill(b,new Rectangle(x-6,y-6,size+12,size+12),Palette.Dark*.94f);
        for(int gy=0;gy<BlockWorld.Size;gy++)for(int gx=0;gx<BlockWorld.Size;gx++)
        {
            int t=world.Get(gx,gy);
            ArcadeMenu.Fill(b,new Rectangle(x+gx*cell,y+gy*cell,Math.Max(1,cell-1),Math.Max(1,cell-1)),
                t==0?new Color(31,42,49):Materials[t]);
        }
        Dot(b,x,y,cell,11.5f,11.5f,new Color(117,243,213));
        foreach(var e in enemies)Dot(b,x,y,cell,e.X,e.Y,new Color(240,79,130));
        foreach(var p in players)if(p.Key!=me)Dot(b,x,y,cell,p.Value.X,p.Value.Y,new Color(72,186,244));
        Dot(b,x,y,cell,local.X,local.Y,Palette.Gold);
    }
    private static void Dot(SpriteBatch b,int x,int y,int cell,float px,float py,Color color)
    {
        ArcadeMenu.Fill(b,new Rectangle(x+(int)(px*cell)-2,y+(int)(py*cell)-2,Math.Max(3,cell/2),Math.Max(3,cell/2)),color);
    }
}
