using System;
using System.Collections.Generic;

namespace MinotaurArcade;

// Single-height voxel-style blocks used by the in-game first-person renderer.
// 0 = air, 1 = stone, 2 = copper, 3 = blue crystal, 4 = bedrock, 5 = placed cobblestone.
internal sealed class BlockWorld
{
    public const int Size = 23;
    public int[] Tiles { get; private set; } = new int[Size * Size];
    public int Get(int x, int y) => x < 0 || y < 0 || x >= Size || y >= Size ? 4 : Tiles[x + y * Size];
    public bool Open(float x, float y)
    {
        const float r = .19f;
        return Get((int)(x-r), (int)(y-r)) == 0 && Get((int)(x+r), (int)(y-r)) == 0 &&
               Get((int)(x-r), (int)(y+r)) == 0 && Get((int)(x+r), (int)(y+r)) == 0;
    }
    public bool Set(int x, int y, int type)
    {
        if (x <= 0 || y <= 0 || x >= Size-1 || y >= Size-1 || (x == 11 && y == 11)) return false;
        Tiles[x + y*Size] = type;
        return true;
    }
    public void Apply(int[] data)
    {
        if (data != null && data.Length == Tiles.Length) Array.Copy(data, Tiles, Tiles.Length);
    }
    public BlockWorld(int seed)
    {
        Random r = new(seed);
        for(int y=0;y<Size;y++) for(int x=0;x<Size;x++)
        {
            int type=0;
            if(x == 0 || y == 0 || x == Size-1 || y == Size-1) type = 4;
            else if(Math.Abs(x-11)<=2 && Math.Abs(y-11)<=2) type = 0;
            else
            {
                int value=r.Next(100);
                type = value < 17 ? 1 : value < 24 ? 2 : value < 36 ? 3 : 0;
            }
            Tiles[x+y*Size] = type;
        }
        // Safe passages from the center so every player can start moving.
        for(int i=7;i<=15;i++) { Tiles[11+i*Size]=0;Tiles[i+11*Size]=0; }
        // Guarantee many mineable crystals in the level even with unlucky seeds.
        int crystals=0;
        foreach(int t in Tiles) if(t==3) crystals++;
        for(int y=3;y<Size-3 && crystals<28;y+=2) for(int x=3;x<Size-3 && crystals<28;x+=3)
            if(Tiles[x+y*Size] == 1) {Tiles[x+y*Size]=3;crystals++;}
    }
}

public sealed class BlockActionPacket
{
    public string LobbyId { get; set; } = "";
    public string Action { get; set; } = "";
    public float Angle { get; set; }
}
public sealed class BlockEnemyPacket
{
    public float X { get; set; }
    public float Y { get; set; }
    public int Health { get; set; }
}
public sealed class BlockWorldPacket
{
    public string LobbyId { get; set; } = "";
    public int[] Cells { get; set; } = Array.Empty<int>();
    public List<BlockEnemyPacket> Enemies { get; set; } = new();
    public int Stone { get; set; }
    public int Crystals { get; set; }
    public int CoreHealth { get; set; }
    public int Wave { get; set; }
    public float Seconds { get; set; }
    public bool Finished { get; set; }
    public bool Won { get; set; }
}
