using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using StardewValley;
using StardewValley.Menus;

namespace MinotaurArcade;

internal sealed class ArcadeMenu : IClickableMenu
{
    internal enum Page { Home, Browser, Waiting }
    private readonly ModEntry mod;
    private readonly int mode;
    private readonly Page page;
    private readonly List<(Rectangle rect, string label, Action action)> buttons = new();

    public ArcadeMenu(ModEntry mod, int mode, Page page) : base(0, 0, Game1.uiViewport.Width, Game1.uiViewport.Height)
    {
        this.mod = mod;
        this.mode = mode;
        this.page = page;
        if (page == Page.Browser) mod.QueryLobbies();
    }

    public override void receiveLeftClick(int x, int y, bool playSound = true)
    {
        foreach (var button in buttons.ToArray())
        {
            if (button.rect.Contains(x, y))
            {
                Game1.playSound("smallSelect");
                button.action();
                return;
            }
        }
    }

    public override void receiveKeyPress(Keys key)
    {
        if (key == Keys.Escape)
        {
            if (page == Page.Waiting) mod.LeaveLobby();
            if (page == Page.Browser) mod.OpenCabinet(mode);
            else Game1.exitActiveMenu();
        }
    }

    public override void draw(SpriteBatch b)
    {
        int vw = Game1.uiViewport.Width, vh = Game1.uiViewport.Height;
        b.Draw(Game1.staminaRect, new Rectangle(0, 0, vw, vh), new Color(11, 8, 21) * .94f);
        int w = Math.Min(780, vw - 38);
        int h = Math.Min(650, vh - 40);
        int x = (vw - w) / 2, y = (vh - h) / 2;
        Box(b, new Rectangle(x, y, w, h), Palette.Gold, Palette.Dark);
        buttons.Clear();
        Text(b, "MINOTAUR ARCADE", x + 34, y + 25, Palette.Gold, 1.45f);
        Text(b, mode switch {0=>"АВТОМАТ I  •  ЛАБИРИНТ",1=>"АВТОМАТ II  •  ВЫЖИВАНИЕ",2=>"АВТОМАТ III  •  БЛОКОВЫЕ ПЕЩЕРЫ",_=>"АВТОМАТ IV  •  ЗАЩИТА КРИСТАЛЛА"}, x + 34, y + 78, Palette.Cream);
        Line(b, x + 28, y + 120, w - 56);
        switch (page)
        {
            case Page.Home: DrawHome(b, x, y, w, h); break;
            case Page.Browser: DrawBrowser(b, x, y, w, h); break;
            case Page.Waiting: DrawWaiting(b, x, y, w, h); break;
        }
        // IClickableMenu has no base 'window' in this custom full-screen layout.
        drawMouse(b);
    }

    private void DrawHome(SpriteBatch b, int x, int y, int w, int h)
    {
        string desc = mode switch
        {
            0 => "Найди выход из 3D-лабиринта. Минотавр преследует тебя.",
            1 => "Уцелеть 90 секунд в 3D-лабиринте и не попасться монстру.",
            2 => "Копай 3D-блоки, добывай 14 кристаллов и строй стены с друзьями.",
            _ => "Защити центральный кристалл от 3 волн монстров. Копай и строй."
        };
        Text(b, desc, x + 35, y + 148, Palette.Cream, .85f);
        int bw = Math.Min(540, w - 68), bx = x + (w - bw) / 2;
        int by = y + Math.Min(232, h / 3);
        Button(b, bx, by, bw, 56, "ИГРАТЬ В СОЛО", () => mod.LaunchSolo(mode));
        Button(b, bx, by + 76, bw, 56, "СОЗДАТЬ ЛОББИ", () => mod.CreateLobby(mode));
        Button(b, bx, by + 152, bw, 56, "НАЙТИ ЛОББИ", () => Game1.activeClickableMenu = new ArcadeMenu(mod, mode, Page.Browser));
        Button(b, bx, by + 228, bw, 48, "ВЫЙТИ", () => Game1.exitActiveMenu());
        Text(b, "Кооп работает внутри одной фермы Stardew Valley (до 4 игроков).", x + 30, y + h - 35, Palette.Gold, .72f);
    }

    private void DrawBrowser(SpriteBatch b, int x, int y, int w, int h)
    {
        Text(b, "ДОСТУПНЫЕ ЛОББИ НА ТЕКУЩЕЙ ФЕРМЕ", x + 28, y + 141, Palette.Cream, .9f);
        var rooms = mod.Lobbies.Values.Where(l => l.Mode == mode && !l.Started)
            .OrderBy(l => l.OwnerName).Take(4).ToArray();
        if (rooms.Length == 0)
            Text(b, "Пока никого нет. Друг должен создать лобби на таком же автомате.", x + 27, y + 218, Palette.Gold, .8f);
        for (int i = 0; i < rooms.Length; i++)
        {
            var lobby = rooms[i];
            int yy = y + 196 + i * 74;
            string name = lobby.OwnerName.Length > 24 ? lobby.OwnerName[..24] : lobby.OwnerName;
            Button(b, x + 34, yy, w - 68, 61, $"{name}   |   {lobby.Players.Count}/4   |   ПОДКЛЮЧИТЬСЯ", () => mod.JoinLobby(lobby.Id));
        }
        Button(b, x + 35, y + h - 116, (w - 85) / 2, 55, "ОБНОВИТЬ", mod.QueryLobbies);
        Button(b, x + 50 + (w - 85) / 2, y + h - 116, (w - 85) / 2, 55, "НАЗАД", () => mod.OpenCabinet(mode));
    }

    private void DrawWaiting(SpriteBatch b, int x, int y, int w, int h)
    {
        var lobby = mod.CurrentLobby;
        if (lobby == null)
        {
            Text(b, "Лобби закрыто владельцем.", x + 30, y + 180, Palette.Gold);
            Button(b, x + 40, y + h - 118, w - 80, 56, "НАЗАД", () => mod.OpenCabinet(mode));
            return;
        }
        bool owner = lobby.OwnerId == Game1.player.UniqueMultiplayerID;
        Text(b, owner ? "ЛОББИ СОЗДАНО • ТЫ ВЕДУЩИЙ" : "ВЫ ПОДКЛЮЧЕНЫ К ЛОББИ", x + 30, y + 145, Palette.Gold);
        Text(b, "ИГРОКИ (" + lobby.Players.Count + "/4):", x + 30, y + 190, Palette.Cream);
        for (int i = 0; i < lobby.PlayerNames.Count && i < 4; i++)
        {
            string tag = lobby.Players[i] == lobby.OwnerId ? " [ХОСТ]" : "";
            Text(b, (i + 1) + ". " + lobby.PlayerNames[i] + tag, x + 55, y + 234 + 45 * i, Palette.Cream, .9f);
        }
        Text(b, "Игроки присоединяются через «Найти лобби» на этой же ферме.", x + 32, y + h - 194, Palette.Gold, .73f);
        if (owner) Button(b, x + 30, y + h - 130, (w - 76) / 2, 56, "НАЧАТЬ ИГРУ", mod.StartLobby);
        Button(b, owner ? x + 46 + (w - 76) / 2 : x + 30, y + h - 130,
            owner ? (w - 76) / 2 : w - 60, 56, "ПОКИНУТЬ ЛОББИ", () => { mod.LeaveLobby(); mod.OpenCabinet(mode); });
    }

    private void Button(SpriteBatch b, int x, int y, int w, int h, string label, Action action)
    {
        var rect = new Rectangle(x, y, w, h);
        bool hover = rect.Contains(Game1.getMouseX(), Game1.getMouseY());
        Box(b, rect, hover ? Palette.Cream : Palette.Gold, hover ? new Color(93, 58, 91) : Palette.Ink);
        var size = Game1.smallFont.MeasureString(label);
        float scale = Math.Min(.95f, (w - 16) / Math.Max(1f, size.X));
        var pos = new Vector2(x + (w - size.X * scale) / 2, y + (h - size.Y * scale) / 2);
        b.DrawString(Game1.smallFont, label, pos, Palette.Cream, 0, Vector2.Zero, scale, SpriteEffects.None, 1);
        buttons.Add((rect, label, action));
    }

    internal static void Fill(SpriteBatch b, Rectangle rect, Color color)
    {
        if (rect.Width > 0 && rect.Height > 0) b.Draw(Game1.staminaRect, rect, color);
    }

    internal static void Box(SpriteBatch b, Rectangle rect, Color border, Color center)
    {
        Fill(b, rect, border);
        Fill(b, new Rectangle(rect.X + 3, rect.Y + 3, Math.Max(0, rect.Width - 6), Math.Max(0, rect.Height - 6)), center);
    }

    internal static void Text(SpriteBatch b, string text, int x, int y, Color color, float scale = 1f)
    {
        b.DrawString(Game1.smallFont, text, new Vector2(x, y), color, 0, Vector2.Zero, scale, SpriteEffects.None, 1);
    }

    private static void Line(SpriteBatch b, int x, int y, int w) => Fill(b, new Rectangle(x, y, w, 3), Palette.Gold);
}
