using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using StardewValley;
using StardewValley.Menus;

namespace MinotaurArcade;

// Lightweight software raycaster: draws a pseudo-3D view INSIDE Stardew, no external window/engine.
internal sealed class MazeMenu : IClickableMenu
{
    private const float FieldOfView = 1.08f;
    private readonly ModEntry mod;
    private readonly LobbyData lobby;
    private readonly Maze map;
    private readonly bool solo;
    private readonly bool authority;
    private readonly long playerId;
    private readonly Dictionary<long, Avatar> avatars = new();
    private readonly Avatar local;
    private float monsterX;
    private float monsterY;
    private float clock;
    private float pathTimer;
    private float pathX;
    private float pathY;
    private bool finished;
    private bool won;
    private bool dismissed;
    private readonly List<(float x, float y, Texture2D? texture, Color tint)> billboards = new();

    internal MazeMenu(ModEntry mod, LobbyData lobby, bool solo) : base(0, 0, Game1.uiViewport.Width, Game1.uiViewport.Height)
    {
        this.mod = mod;
        this.lobby = lobby;
        this.solo = solo;
        authority = solo || lobby.OwnerId == Game1.player.UniqueMultiplayerID;
        playerId = Game1.player.UniqueMultiplayerID;
        map = new Maze(lobby.Seed, lobby.Mode);
        foreach (long id in lobby.Players)
            avatars[id] = new Avatar();
        if (!avatars.ContainsKey(playerId)) avatars[playerId] = new Avatar();
        local = avatars[playerId];
        monsterX = map.Size - 1.5f;
        monsterY = 1.5f;
        pathX = monsterX;
        pathY = monsterY;
        Game1.playSound("doorClose");
    }

    internal void Tick(bool sendState)
    {
        if (dismissed) return;
        const float dt = 1f / 60f;
        if (!finished)
        {
            if (!local.Caught && !local.Escaped) HandleMovement(dt);
            if (lobby.Mode == 0 && !local.Caught && !local.Escaped &&
                Math.Abs(local.X - (map.ExitX + .5f)) < .45f &&
                Math.Abs(local.Y - (map.ExitY + .5f)) < .45f)
            {
                local.Escaped = true;
                Game1.playSound("reward");
            }
            if (authority)
            {
                clock += dt;
                MoveMonster(dt);
                CheckGameOver();
            }
        }
        if (!solo && sendState)
        {
            mod.Broadcast("PlayerState", new PlayerPacket
            {
                LobbyId = lobby.Id, X = local.X, Y = local.Y, Angle = local.Angle,
                Escaped = local.Escaped, Caught = local.Caught
            });
            if (authority)
                mod.Broadcast("MonsterState", new MonsterPacket
                {
                    LobbyId = lobby.Id, X = monsterX, Y = monsterY, Seconds = clock,
                    Finished = finished, Won = won,
                    CaughtIds = avatars.Where(p => p.Value.Caught).Select(p => p.Key).ToList(),
                    EscapedIds = avatars.Where(p => p.Value.Escaped).Select(p => p.Key).ToList()
                });
        }
    }

    private void HandleMovement(float dt)
    {
        var keys = Keyboard.GetState();
        bool turnLeft = keys.IsKeyDown(Keys.Left) || keys.IsKeyDown(Keys.A);
        bool turnRight = keys.IsKeyDown(Keys.Right) || keys.IsKeyDown(Keys.D);
        if (turnLeft) local.Angle -= 2.5f * dt;
        if (turnRight) local.Angle += 2.5f * dt;
        float forward = (keys.IsKeyDown(Keys.W) || keys.IsKeyDown(Keys.Up) ? 1 : 0)
                      - (keys.IsKeyDown(Keys.S) || keys.IsKeyDown(Keys.Down) ? 1 : 0);
        float sideways = (keys.IsKeyDown(Keys.E) ? 1 : 0) - (keys.IsKeyDown(Keys.Q) ? 1 : 0);
        float speed = keys.IsKeyDown(Keys.LeftShift) ? 3.3f : 2.35f;
        float dx = (MathF.Cos(local.Angle) * forward - MathF.Sin(local.Angle) * sideways) * speed * dt;
        float dy = (MathF.Sin(local.Angle) * forward + MathF.Cos(local.Angle) * sideways) * speed * dt;
        if (map.Walkable(local.X + dx, local.Y)) local.X += dx;
        if (map.Walkable(local.X, local.Y + dy)) local.Y += dy;
    }

    private void MoveMonster(float dt)
    {
        // A short grace period lets everyone orient themselves in the maze.
        if (clock < 7f) return;
        var targets = avatars.Values.Where(a => !a.Caught && !a.Escaped).ToArray();
        if (targets.Length == 0) return;
        var target = targets.OrderBy(a => DistSq(a.X, a.Y, monsterX, monsterY)).First();
        pathTimer -= dt;
        if (pathTimer <= 0)
        {
            (pathX, pathY) = map.NextPathStep(monsterX, monsterY, target.X, target.Y);
            pathTimer = .23f;
        }
        float dx = pathX - monsterX, dy = pathY - monsterY;
        float length = MathF.Sqrt(dx * dx + dy * dy);
        if (length > .025f)
        {
            float speed = lobby.Mode == 0 ? 1.00f : 1.24f;
            float step = Math.Min(length, speed * dt);
            float nx = monsterX + dx / length * step;
            float ny = monsterY + dy / length * step;
            if (map.Walkable(nx, monsterY)) monsterX = nx;
            if (map.Walkable(monsterX, ny)) monsterY = ny;
        }
        foreach (Avatar player in targets)
        {
            if (DistSq(player.X, player.Y, monsterX, monsterY) < .39f * .39f)
            {
                player.Caught = true;
                if (ReferenceEquals(player, local)) Game1.playSound("monsterhit");
            }
        }
    }

    private void CheckGameOver()
    {
        var roster = lobby.Players.Select(id => avatars[id]).ToArray();
        if (lobby.Mode == 0)
        {
            if (roster.All(a => a.Caught || a.Escaped))
            {
                finished = true;
                won = roster.Any(a => a.Escaped);
            }
        }
        else if (clock >= 90)
        {
            finished = true;
            won = roster.Any(a => !a.Caught);
        }
        else if (roster.All(a => a.Caught))
        {
            finished = true;
            won = false;
        }
        if (finished) Game1.playSound(won ? "reward" : "thunder");
    }

    private static float DistSq(float ax, float ay, float bx, float by) => (ax - bx) * (ax - bx) + (ay - by) * (ay - by);

    internal void ReceivePlayer(long sender, PlayerPacket packet)
    {
        if (packet.LobbyId != lobby.Id || sender == playerId || !avatars.TryGetValue(sender, out Avatar? target))
            return;
        // Don't accept nonsensical remote coordinates.
        if (packet.X > 0 && packet.X < map.Size && packet.Y > 0 && packet.Y < map.Size)
        {
            target.X = packet.X; target.Y = packet.Y;
            target.Angle = packet.Angle;
            target.Escaped = target.Escaped || packet.Escaped;
            target.Caught = target.Caught || packet.Caught;
        }
    }

    internal void ReceiveMonster(long sender, MonsterPacket packet)
    {
        if (authority || packet.LobbyId != lobby.Id || sender != lobby.OwnerId) return;
        monsterX = packet.X;
        monsterY = packet.Y;
        clock = packet.Seconds;
        foreach (long id in packet.CaughtIds)
            if (avatars.TryGetValue(id, out Avatar? caught)) caught.Caught = true;
        foreach (long id in packet.EscapedIds)
            if (avatars.TryGetValue(id, out Avatar? escaped)) escaped.Escaped = true;
        if (packet.Finished && !finished)
            Game1.playSound(packet.Won ? "reward" : "thunder");
        finished = packet.Finished;
        won = packet.Won;
        if (!finished && DistSq(local.X, local.Y, monsterX, monsterY) < .39f * .39f)
            local.Caught = true;
    }

    internal void CancelFromHost()
    {
        finished = true;
        won = false;
    }

    public override void receiveKeyPress(Keys key)
    {
        if (key == Keys.Escape)
        {
            ExitGame();
            return;
        }
        if (finished && key == Keys.R && solo)
        {
            mod.LaunchSolo(lobby.Mode);
        }
    }

    private void ExitGame()
    {
        dismissed = true;
        if (!solo)
        {
            if (authority)
                mod.Broadcast("MonsterState", new MonsterPacket { LobbyId = lobby.Id, X = monsterX, Y = monsterY, Seconds = clock, Finished = true, Won = false });
            else
                mod.Broadcast("PlayerState", new PlayerPacket { LobbyId = lobby.Id, X = local.X, Y = local.Y, Angle = local.Angle, Caught = true });
            mod.LeaveLobby();
        }
        mod.OpenCabinet(lobby.Mode);
    }

    public override void draw(SpriteBatch b)
    {
        int w = Game1.uiViewport.Width, h = Game1.uiViewport.Height;
        ArcadeMenu.Fill(b, new Rectangle(0, 0, w, h), new Color(12, 9, 23));
        int pad = Math.Min(35, w / 20), top = 67;
        var screen = new Rectangle(pad, top, Math.Max(100, w - pad * 2), Math.Max(100, h - 166));
        ArcadeMenu.Box(b, new Rectangle(screen.X - 3, screen.Y - 3, screen.Width + 6, screen.Height + 6), Palette.Gold, Palette.Dark);
        RenderFirstPerson(b, screen);
        RenderMinimap(b, screen);
        ArcadeMenu.Text(b, lobby.Mode == 0 ? "MINOTAUR MAZE // НАЙДИ ВЫХОД" : "MINOTAUR SURVIVAL // ПРОДЕРЖИСЬ 90 СЕКУНД", pad, 18, Palette.Gold, .95f);
        ArcadeMenu.Text(b, $"ВРЕМЯ: {clock:0.0} с   •   ИГРОКОВ: {avatars.Count}   •   " +
            (local.Caught ? "ТЕБЯ ПОЙМАЛИ" : local.Escaped ? "ТЫ ВЫБРАЛСЯ" : "В ИГРЕ"),
            pad + 3, screen.Bottom + 11, Palette.Cream, .82f);
        ArcadeMenu.Text(b, "W/S — идти   A/D или ←/→ — поворот   Q/E — шаг вбок   SHIFT — бег   ESC — выход",
            pad + 3, h - 46, Palette.Gold, .78f);
        if (finished)
        {
            int bw = Math.Min(screen.Width - 30, 650), bh = 165;
            int bx = screen.Center.X - bw / 2, by = screen.Center.Y - bh / 2;
            ArcadeMenu.Box(b, new Rectangle(bx, by, bw, bh), Palette.Gold, new Color(31, 24, 46));
            ArcadeMenu.Text(b, won ? "ПОБЕДА!" : "ИГРА ОКОНЧЕНА", bx + 30, by + 22, won ? Palette.Gold : new Color(239, 111, 103), 1.32f);
            ArcadeMenu.Text(b, solo ? "R — повторить   •   ESC — выйти" : "ESC — вернуться к автомату", bx + 30, by + 92, Palette.Cream, .9f);
        }
        drawMouse(b);
    }

    private void RenderFirstPerson(SpriteBatch b, Rectangle area)
    {
        // Static 'sky' and 'floor' are textured in broad bands; walls get depth-based light.
        int horizon = area.Y + area.Height / 2;
        ArcadeMenu.Fill(b, new Rectangle(area.X, area.Y, area.Width, area.Height / 2), new Color(26, 21, 43));
        ArcadeMenu.Fill(b, new Rectangle(area.X, horizon, area.Width, area.Height - area.Height / 2), new Color(46, 40, 47));
        for (int n = 0; n < 7; n++)
        {
            int yy = horizon + (n * n + 3 * n) * (area.Height / 115);
            if (yy < area.Bottom)
                ArcadeMenu.Fill(b, new Rectangle(area.X, yy, area.Width, 1), new Color(77, 69, 66) * .38f);
        }
        const int columnWidth = 4;
        int columns = (area.Width + columnWidth - 1) / columnWidth;
        var zBuffer = new float[columns];
        for (int i = 0; i < columns; i++)
        {
            float rayAngle = local.Angle - FieldOfView / 2f + (i + .5f) * FieldOfView / columns;
            float rayX = MathF.Cos(rayAngle), rayY = MathF.Sin(rayAngle);
            int gridX = (int)local.X, gridY = (int)local.Y;
            float deltaX = Math.Abs(rayX) < .000001f ? 100000f : Math.Abs(1f / rayX);
            float deltaY = Math.Abs(rayY) < .000001f ? 100000f : Math.Abs(1f / rayY);
            int stepX = rayX < 0 ? -1 : 1, stepY = rayY < 0 ? -1 : 1;
            float sideX = (rayX < 0 ? local.X - gridX : gridX + 1f - local.X) * deltaX;
            float sideY = (rayY < 0 ? local.Y - gridY : gridY + 1f - local.Y) * deltaY;
            bool side = false;
            for (int tries = 0; tries < map.Size * map.Size; tries++)
            {
                if (sideX < sideY) { sideX += deltaX; gridX += stepX; side = false; }
                else { sideY += deltaY; gridY += stepY; side = true; }
                if (map.Wall(gridX, gridY)) break;
            }
            float distance = Math.Max(.08f, (side ? sideY - deltaY : sideX - deltaX) * MathF.Cos(rayAngle - local.Angle));
            zBuffer[i] = distance;
            int wallHeight = Math.Min(area.Height * 3, (int)(area.Height * .83f / distance));
            int wallY = horizon - wallHeight / 2;
            float brightness = Math.Clamp(1.1f / (1f + distance * .16f), .2f, 1f) * (side ? .78f : 1f);
            Color stone = new Color(142, 117, 121) * brightness;
            int x = area.X + i * columnWidth;
            int width = Math.Min(columnWidth, area.Right - x);
            if (width < 1) continue;
            int visibleY = Math.Max(area.Top, wallY), bottom = Math.Min(area.Bottom, wallY + wallHeight);
            ArcadeMenu.Fill(b, new Rectangle(x, visibleY, width, Math.Max(0, bottom - visibleY)), stone);
            // Mortar strokes and vertical tiles make walls read as physical masonry.
            if (wallHeight >= 16)
            {
                int stripe = Math.Max(7, wallHeight / 7);
                for (int yy = wallY + stripe; yy < bottom; yy += stripe)
                {
                    if (yy >= area.Y)
                        ArcadeMenu.Fill(b, new Rectangle(x, yy, width, Math.Max(1, wallHeight / 150)), new Color(48, 38, 46) * brightness);
                }
            }
            if ((i % 7) == 0)
                ArcadeMenu.Fill(b, new Rectangle(x, visibleY, 1, Math.Max(0, bottom - visibleY)), new Color(50, 39, 50) * brightness);
        }
        billboards.Clear();
        billboards.Add((monsterX, monsterY, mod.MinotaurTexture, Color.White));
        foreach (var kv in avatars)
        {
            if (kv.Key != playerId && !kv.Value.Caught && !kv.Value.Escaped)
                billboards.Add((kv.Value.X, kv.Value.Y, null, new Color(73, 219, 242)));
        }
        foreach (var sprite in billboards.OrderByDescending(p => DistSq(local.X, local.Y, p.x, p.y)))
            DrawBillboard(b, area, zBuffer, sprite.x, sprite.y, sprite.texture, sprite.tint);
        if (lobby.Mode == 0)
            DrawBillboard(b, area, zBuffer, map.ExitX + .5f, map.ExitY + .5f, null, new Color(139, 248, 140));
        // Center reticle.
        ArcadeMenu.Fill(b, new Rectangle(area.Center.X - 7, area.Center.Y, 14, 1), Palette.Cream * .55f);
        ArcadeMenu.Fill(b, new Rectangle(area.Center.X, area.Center.Y - 7, 1, 14), Palette.Cream * .55f);
        if (local.Caught)
            ArcadeMenu.Fill(b, area, new Color(150, 17, 22) * .34f);
        if (local.Escaped)
            ArcadeMenu.Fill(b, area, new Color(20, 140, 43) * .25f);
    }

    private void DrawBillboard(SpriteBatch b, Rectangle area, float[] depth, float spriteX, float spriteY, Texture2D? art, Color tint)
    {
        float dx = spriteX - local.X, dy = spriteY - local.Y;
        float d = MathF.Sqrt(dx * dx + dy * dy);
        if (d < .15f) return;
        float relative = MathF.Atan2(dy, dx) - local.Angle;
        while (relative > MathF.PI) relative -= MathF.Tau;
        while (relative < -MathF.PI) relative += MathF.Tau;
        if (Math.Abs(relative) > FieldOfView * .67f) return;
        float corrected = d * MathF.Cos(relative);
        float cx = area.Center.X + relative / FieldOfView * area.Width;
        int height = (int)(area.Height * (art == null ? .44f : .81f) / Math.Max(.1f, corrected));
        height = Math.Min(height, area.Height * 3);
        int width = (int)(height * (art == null ? .48f : .75f));
        int centerColumn = Math.Clamp((int)((cx - area.X) / 4), 0, depth.Length - 1);
        if (corrected > depth[centerColumn] + .08f) return;
        var rect = new Rectangle((int)cx - width / 2, area.Center.Y - height / 2, width, height);
        if (art != null)
            b.Draw(art, rect, tint * Math.Clamp(1.4f / (1f + corrected * .12f), .38f, 1));
        else
        {
            ArcadeMenu.Fill(b, rect, tint * .8f);
            ArcadeMenu.Fill(b, new Rectangle(rect.X + rect.Width / 4, rect.Y + rect.Height / 6,
                rect.Width / 2, Math.Max(2, rect.Height / 6)), Color.White * .75f);
        }
    }

    private void RenderMinimap(SpriteBatch b, Rectangle area)
    {
        int tile = Math.Clamp(Math.Min(area.Width / (map.Size + 13), area.Height / (map.Size + 5)), 5, 11);
        int size = tile * map.Size;
        int x = area.Right - size - 14;
        int y = area.Y + 14;
        ArcadeMenu.Fill(b, new Rectangle(x - 6, y - 6, size + 12, size + 12), Palette.Dark * .94f);
        for (int gy = 0; gy < map.Size; gy++)
            for (int gx = 0; gx < map.Size; gx++)
                ArcadeMenu.Fill(b, new Rectangle(x + gx * tile, y + gy * tile, tile - 1, tile - 1),
                    map.Wall(gx, gy) ? new Color(90, 79, 112) : new Color(38, 35, 44));
        Dot(b, x, y, tile, map.ExitX + .5f, map.ExitY + .5f, new Color(113, 229, 125));
        Dot(b, x, y, tile, monsterX, monsterY, new Color(241, 92, 81));
        foreach (var item in avatars)
            if (item.Key != playerId && !item.Value.Caught && !item.Value.Escaped)
                Dot(b, x, y, tile, item.Value.X, item.Value.Y, new Color(80, 202, 255));
        Dot(b, x, y, tile, local.X, local.Y, Palette.Gold);
    }

    private static void Dot(SpriteBatch b, int x, int y, int tile, float px, float py, Color color)
    {
        int sx = x + (int)(px * tile), sy = y + (int)(py * tile);
        ArcadeMenu.Fill(b, new Rectangle(sx - 2, sy - 2, Math.Max(4, tile / 2), Math.Max(4, tile / 2)), color);
    }
}
