using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;

namespace MinotaurArcade;

public sealed class LobbyData
{
    public string Id { get; set; } = "";
    public int Mode { get; set; }
    public long OwnerId { get; set; }
    public string OwnerName { get; set; } = "";
    public List<long> Players { get; set; } = new();
    public List<string> PlayerNames { get; set; } = new();
    public int Seed { get; set; }
    public bool Started { get; set; }
}

public sealed class LobbyRequest
{
    public string LobbyId { get; set; } = "";
    public string PlayerName { get; set; } = "";
}

public sealed class LobbyControl
{
    public string LobbyId { get; set; } = "";
    public long PlayerId { get; set; }
}

public sealed class PlayerPacket
{
    public string LobbyId { get; set; } = "";
    public float X { get; set; }
    public float Y { get; set; }
    public float Angle { get; set; }
    public bool Escaped { get; set; }
    public bool Caught { get; set; }
}

public sealed class MonsterPacket
{
    public string LobbyId { get; set; } = "";
    public float X { get; set; }
    public float Y { get; set; }
    public float Seconds { get; set; }
    public bool Finished { get; set; }
    public bool Won { get; set; }
    public List<long> CaughtIds { get; set; } = new();
    public List<long> EscapedIds { get; set; } = new();
}

internal sealed class Avatar
{
    public float X = 1.5f;
    public float Y = 1.5f;
    public float Angle = 0;
    public bool Escaped;
    public bool Caught;
}

internal static class Palette
{
    public static readonly Color Cream = new(239, 221, 188);
    public static readonly Color Gold = new(244, 177, 79);
    public static readonly Color Dark = new(25, 20, 35);
    public static readonly Color Ink = new(49, 40, 64);
}
