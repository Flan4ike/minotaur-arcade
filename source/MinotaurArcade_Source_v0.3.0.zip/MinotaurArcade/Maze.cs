using System;
using System.Collections.Generic;

namespace MinotaurArcade;

internal sealed class Maze
{
    public int Size { get; }
    private readonly bool[,] walls;
    public int ExitX => Size - 2;
    public int ExitY => Size - 2;

    public Maze(int seed, int mode)
    {
        Size = mode == 0 ? 17 : 19;
        walls = new bool[Size, Size];
        for (int x = 0; x < Size; ++x)
            for (int y = 0; y < Size; ++y)
                walls[x, y] = true;
        var random = new Random(seed);
        var stack = new Stack<(int x, int y)>();
        walls[1, 1] = false;
        stack.Push((1, 1));
        while (stack.Count > 0)
        {
            var (x, y) = stack.Peek();
            var choices = new List<(int x, int y)>();
            foreach (var (dx, dy) in new[] { (2, 0), (-2, 0), (0, 2), (0, -2) })
            {
                int nx = x + dx, ny = y + dy;
                if (nx > 0 && nx < Size - 1 && ny > 0 && ny < Size - 1 && walls[nx, ny])
                    choices.Add((nx, ny));
            }
            if (choices.Count == 0) { stack.Pop(); continue; }
            var next = choices[random.Next(choices.Count)];
            walls[(next.x + x) / 2, (next.y + y) / 2] = false;
            walls[next.x, next.y] = false;
            stack.Push(next);
        }
    }

    public bool Wall(int x, int y) => x < 0 || x >= Size || y < 0 || y >= Size || walls[x, y];

    public bool Walkable(float x, float y)
    {
        const float radius = .16f;
        return !Wall((int)Math.Floor(x - radius), (int)Math.Floor(y - radius))
            && !Wall((int)Math.Floor(x + radius), (int)Math.Floor(y - radius))
            && !Wall((int)Math.Floor(x - radius), (int)Math.Floor(y + radius))
            && !Wall((int)Math.Floor(x + radius), (int)Math.Floor(y + radius));
    }

    public (float x, float y) NextPathStep(float sx, float sy, float tx, float ty)
    {
        // BFS gives the minotaur shortest turns through the actual generated maze.
        int startX = Math.Clamp((int)sx, 0, Size - 1);
        int startY = Math.Clamp((int)sy, 0, Size - 1);
        int goalX = Math.Clamp((int)tx, 0, Size - 1);
        int goalY = Math.Clamp((int)ty, 0, Size - 1);
        int[,] distance = new int[Size, Size];
        for (int x = 0; x < Size; ++x)
            for (int y = 0; y < Size; ++y)
                distance[x, y] = -1;
        var queue = new Queue<(int x, int y)>();
        queue.Enqueue((goalX, goalY));
        distance[goalX, goalY] = 0;
        while (queue.Count > 0)
        {
            var (x, y) = queue.Dequeue();
            foreach (var (dx, dy) in new[] { (1, 0), (0, 1), (-1, 0), (0, -1) })
            {
                int nx = x + dx, ny = y + dy;
                if (!Wall(nx, ny) && distance[nx, ny] < 0)
                {
                    distance[nx, ny] = distance[x, y] + 1;
                    queue.Enqueue((nx, ny));
                }
            }
        }
        int bestX = startX, bestY = startY;
        int bestD = distance[startX, startY];
        foreach (var (dx, dy) in new[] { (1, 0), (0, 1), (-1, 0), (0, -1) })
        {
            int nx = startX + dx, ny = startY + dy;
            if (!Wall(nx, ny) && distance[nx, ny] >= 0 && (bestD < 0 || distance[nx, ny] < bestD))
            {
                bestD = distance[nx, ny]; bestX = nx; bestY = ny;
            }
        }
        // Walking toward cell centers prevents snagging on maze corners.
        return (bestX + .5f, bestY + .5f);
    }
}
